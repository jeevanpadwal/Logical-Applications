
import java.lang.*;
import java.util.*;
import java.io.*;

class File_Operation
{
    void Creat_File(String str)
    {
        try
        {
            File file = new File("C:/Users/G1/Desktop/LBA/assignment42/"+str);

          boolean fd =  file.createNewFile();
            if(fd)
            {
                System.out.println("FIle Created sussesful ");
            }
            else
            {
                System.out.println("File alredy present ");
            }
        }
        catch(IOException obj){}

    }

}

class Pro4
{
   public static void main(String arg[])
   {
      Scanner sobj = new Scanner(System.in);
      File_Operation fobj = new File_Operation();

      System.out.println("Enter file name :");
      String file_name = sobj.nextLine();

        fobj.Creat_File(file_name);
   }
}