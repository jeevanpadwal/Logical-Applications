import java.lang.*;
import java.util.*;
import java.io.*;


class Pro5 
{
   public static void main(String args[]) throws IOException 
   {
      Scanner sobj =new Scanner(System.in);
     System.out.println("ENter Directory name :");
     String str =sobj.nextLine();
    
    File fNames = new File("C:/Users/G1/Desktop/LBA/"+str);
      
      String contents[] = fNames.list();
      System.out.println("List of files and directories in the specified directory:");
      for(int i=0; i<contents.length; i++) 
      {
         System.out.println(contents[i]);
      }
   }
}