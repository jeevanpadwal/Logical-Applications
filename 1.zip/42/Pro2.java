//get file name and disply data on consol
import java.lang.*;
import java.util.*;
import java.io.*;

class File_Operation
{
    void Open_File(String str)
    {
        try
        {
            File file = new File("C:/Users/G1/Desktop/LBA/assignment42/"+str);

           Scanner sc = new Scanner(file);
           while(sc.hasNextLine())
           {
            System.out.println(sc.nextLine());
           }
        }
        catch(IOException obj){}

    }

}

class Pro2
{
   public static void main(String arg[])
   {
      Scanner sobj = new Scanner(System.in);
      File_Operation fobj = new File_Operation();

      System.out.println("Enter file name :");
      String file_name = sobj.nextLine();

        fobj.Open_File(file_name);
   }
}