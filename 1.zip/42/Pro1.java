//accept file name and open that file
import java.lang.*;
import java.util.*;
import java.io.*;

class File_Operation
{
    void Open_File(String str)
    {
        try
        {
            File file = new File("C:/Users/G1/Desktop/LBA/assignment42/"+str);

            boolean flag = file.createNewFile();
            if(flag)
            {
                System.out.println("File created successfully ");
            }
            else
            {
                System.out.println("File alredy present ");
            }
        }
        catch(IOException obj){}

    }

}

class Pro1
{
   public static void main(String arg[])
   {
      Scanner sobj = new Scanner(System.in);
      File_Operation fobj = new File_Operation();

      System.out.println("Enter file name :");
      String file_name = sobj.nextLine();

        fobj.Open_File(file_name);
   }
}