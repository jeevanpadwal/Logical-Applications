//accept string from user and shoe only ditigit
#include<iostream>
using namespace std;

void DisplayDigit(char *ch)
{
   while( *ch != '\0')
   {
       if(*ch >= '0' && *ch <= '9' )
       {
           cout<<*ch<<endl;
       }
       ch++;
   }
}

int main()
{
    char cValue[30];

    cout<<"Enter the String :"<<endl;
    cin.getline(cValue,30);

    DisplayDigit(cValue);

    return 0;
}