//accept string from user and convert it into lower case
#include<iostream>
using namespace std;

void strlwrx(char *ch)
{
   while( *ch != '\0')
   {
       if(*ch >='A'&& *ch <='Z')
       {
           *ch=*ch +32;
       }

       ch++;
   }
}

int main()
{
    char cValue[30];

    cout<<"Enter the String :"<<endl;
    cin.getline(cValue,30);

    strlwrx(cValue);

    cout<<cValue;

    return 0;
}