//accept string from user and count white spacess
#include<iostream>
using namespace std;

int CountWhite(char *ch)
{
    int iCnt=0;

   while( *ch != '\0')
   {
       if(*ch == 32 )
       {
           iCnt++;
       }
       ch++;
   }
   return iCnt;
}

int main()
{
    char cValue[30];
    int iRet=0;

    cout<<"Enter the String :"<<endl;
    cin.getline(cValue,30);

    iRet= CountWhite(cValue);
    cout<<"Number of ehite spaces :"<<iRet;

    return 0;
}