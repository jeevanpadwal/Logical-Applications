//accept string from user and convert it into upper case
#include<iostream>
using namespace std;

void struprx(char *ch)
{
   while( *ch != '\0')
   {
       if(*ch >='a'&& *ch <='z')
       {
           *ch=*ch - 32;
       }

       ch++;
   }
}

int main()
{
    char cValue[30];

    cout<<"Enter the String :"<<endl;
    cin.getline(cValue,30);

    struprx(cValue);

    cout<<cValue;

    return 0;
}