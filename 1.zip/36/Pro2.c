//output :1 2 3 4 5

#include<stdio.h>

void Display()
{
    static int iCnt=0;
     if(iCnt < 5 )
    {
        iCnt++;
        printf("%d\t",iCnt);
        Display();
    }
}

int main()
{
    Display();

    return 0;
}