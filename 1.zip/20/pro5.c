//Give perfect no from linkl list

#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
};
typedef struct node NODE;
typedef struct node * PNODE;
typedef struct node ** PPNODE;

void InsertFirst(PPNODE head,int no)
{
    PNODE newn=NULL;

    newn = (PNODE)malloc(sizeof(NODE));

    newn->data=no;
    newn->next=NULL;

    if(*head==NULL)
    {
        *head=newn;
    }
    else
    {
        newn->next= *head;
        *head=newn;
    }
}

void Display(PNODE head)
{

    while(head!=NULL)
    {
        
        printf("|%d|->",head->data);
        head=head->next;
    }
    printf("SAMPLI KI\n");
}

int SumDigit(PNODE head)
{
    int iCnt=0;
    int iDigit=0,iSum=0,temp=0;
     
    while(head!= NULL)
    {
        iSum=0;

        while((head->data)>0)
        {
           iDigit=(head->data) % 10;

           iSum=iDigit+iSum;
    

            head->data=head->data/10;
        }
       
      head=head->next; 

      printf("Addition of didit is %d\n",iSum); 
    }

   
}

int main()
{
PNODE first=NULL;
int ret=0;

InsertFirst(&first,640);
InsertFirst(&first,240);
InsertFirst(&first,20);
InsertFirst(&first,230);
InsertFirst(&first,110);

Display(first);

ret=SumDigit(first);



 return 0;
}