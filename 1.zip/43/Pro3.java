import java.lang.*;
import java.util.*;
import java.io.*;

class File_Operation
{
    void MkDir(String Name)
    {
        File file = new File("C:/Users/G1/Desktop/LBA/assignment43/"+Name);

        boolean chk = file.mkdir();

        if(chk)
        {
            System.out.println("Directory is created Successfull with name:"+Name);
        }
        else
        {
            System.out.println("Directory is not Created ");
        }

    }
}

class Pro3
{
    public static void main(String arg[])
    {
        Scanner sobj = new Scanner(System.in);
        File_Operation fo = new File_Operation();

        System.out.println("Enter directory name :");
        String Name = sobj.nextLine();

        fo.MkDir(Name);
    }
}