import java.lang.*;
import java.util.*;
import java.io.*;

class File_Operation
{
    public static long getFileSize(String filename)
    {
       File file = new File(filename);
      if (!file.exists() || !file.isFile()) {
         System.out.println("File doesn\'t exist");
         return -1;
      }
      return file.length();

    }
    void NameSize(String Name)
    {
        File path =new File("C:/Users/G1/Desktop/LBA/"+Name);

        String contents[] = path.list();

      System.out.println("List of files and directories in the specified directory:");
      for(int i=0; i<contents.length; i++) 
      {
       
        System.out.println(contents[i]);
        long size1 = getFileSize(contents[i]);
        System.out.println("File size in bytes :"+size1);  
         
      }

    }
}

class Pro5
{
    public static void main(String arg[])
    {
        Scanner sobj = new Scanner(System.in);
        File_Operation fo = new File_Operation();

        System.out.println("Enter directory name :");
        String Name = sobj.nextLine();

        fo.NameSize(Name);
    }
}