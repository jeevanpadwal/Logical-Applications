import java.lang.*;
import java.util.*;
import java.io.*;

class File_Operation
{
    void ChkReguler(String Name)
    {
        File file = new File("C:/Users/G1/Desktop/LBA/assignment43/"+Name);

        if(file.isFile())
        {
            System.out.println("File is reguler :"+Name);
        }
        else
        {
            System.out.println("File is not reguler :"+Name);
        }

    }
}

class Pro2
{
    public static void main(String arg[])
    {
        Scanner sobj = new Scanner(System.in);
        File_Operation fo = new File_Operation();

        System.out.println("Enter file name :");
        String Name = sobj.nextLine();

        fo.ChkReguler(Name);
    }
}