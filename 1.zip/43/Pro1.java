import java.lang.*;
import java.util.*;
import java.io.*;

class Operation
{
    void fileCopy(String source,String destination) throws IOException
    {
        File file = new File("C:/Users/G1/Desktop/LBA/assignment43/"+source);
        File dest = new File("C:/Users/G1/Desktop/LBA/assignment43/"+destination);

         boolean flag = dest.createNewFile();
         if(flag)
         {
            System.out.println("File created suseesful");
         }
         else
         {
            System.out.println("File is alredy present ");
         }

        FileWriter fWriter =new FileWriter(dest);

        Scanner scan = new Scanner(file);
        while(scan.hasNextLine())
        {
            String line = scan.nextLine();

            fWriter.write(line);
        }
        fWriter.close();
    }
}

class Pro1
{
    public static void main(String arg[]) throws IOException
    {
        Scanner sobj = new Scanner(System.in);
        Operation oobj = new Operation();

        System.out.println("Enter file to open :");
        String openFile =sobj.nextLine();

        System.out.println("Enter file name to copy :");
        String copyFile=sobj.nextLine();

       oobj.fileCopy(openFile,copyFile);

    }
}