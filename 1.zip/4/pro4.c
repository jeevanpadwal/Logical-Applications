//accept no. return summation of all non factor

#include<stdio.h>

int SumNonF(int iNo)
{
    int iCnt=0;
    int iSum=0;
    for(iCnt=1;iCnt<=iNo;iCnt++)
    {
        if((iNo%iCnt)!=0)
        {
            iSum=iSum+iCnt;
        }
    }
    return iSum;
}

int main()
{
    int iValue=0;
    int iRet=0;

    printf("enter no");
    scanf("%d",&iValue);

    iRet=SumNonF(iValue);

    printf("addition of non factor is :%d\n",iRet);

    return 0;
}