//display multiplication of its factors
#include<stdio.h>
int MultFact(int iNo)
{
    int i=0;
    int FactMult=1;
    for(i=1;i<=iNo/2;i++)
    {
        if(iNo%i==0)
        {
            FactMult=FactMult*i;
        }
    }

    return FactMult;
}

int main()
{
    int iValue=0;
    int iRet=0;

    printf("enter no");
    scanf("%d",&iValue);

    iRet=MultFact(iValue);

    printf("multiplicatin of factor is %d\n",iRet);

    return 0;
}