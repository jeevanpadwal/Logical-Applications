
// accept no return defferance between factor and non factor
#include<stdio.h>
int FactDiff(int iNo)
{
    int iCnt=0;
    int iSum=0;
    int iSumN=0;
    int Diff=0;
    
   
    for(iCnt=1;iCnt<=iNo;iCnt++)
    {
        if((iNo%iCnt)==0)
        {
            iSum=iSum+iCnt;
        }
    }
     for(iCnt=1;iCnt<=iNo;iCnt++)
    {
        if((iNo%iCnt)!=0)
        {
            iSumN=iSumN+iCnt;
        }
    }
    Diff=iSum-iSumN;
    

    
    return Diff;

}



int main()

{
    int iValue=0;
    int iRet=0;

    printf("enter no");
    scanf("%d",&iValue);

    iRet=FactDiff(iValue);

    printf("differance is :%d",iRet);

return 0;
}