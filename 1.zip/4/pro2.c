//display factor in decresing order
#include<stdio.h>
void FactD(int iNo)
{
    int i=0;
    for(i=iNo;i>=1;i--)
    {
    
        if((iNo%i)==0)
        {
            
            printf("%d\n",i);
        }

    }
}

int main()
{
    int iValue=0;

    printf("enter no\n");
    scanf("%d",&iValue);

    FactD(iValue);

    return 0;
}

