//generic for finding largest number from three number

#include<iostream>
using namespace std;

int main()