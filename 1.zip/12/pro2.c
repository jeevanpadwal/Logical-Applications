#include<stdio.h>
void Display(int iNo)
{
    int iCnt=0;

    for(iCnt=iNo;iCnt>=1;iCnt--)
    {
        printf("%d\t#\t",iCnt);

    }
}

int main()
{
    int iValue=0;

    printf("enter how many element you want");
    scanf("%d",&iValue);

    Display(iValue);

    return 0;
}