//Display ASKII table
#include<iostream>
using namespace std;

void DisplayASCII()
{
   int Value=0;

   for(int iCnt = 0;iCnt <=255;iCnt++)
   {
       cout<<"Ascii Value of Number :"<<iCnt<<" is : "<<char(iCnt)<<endl;
   }
}

int main()
{
    DisplayASCII();

    return 0;
}