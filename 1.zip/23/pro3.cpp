//accept character from user .if it is capita then display all the character form the input characters till Z 
// if input character is small then print all  character in reverse order till a/
//in other case return directly

#include<iostream>
using namespace std;

void Display(char ch[])
{
    char cCnt='\0';
    
      if( *ch >= 'A' && *ch <='Z')
      {
          for(cCnt=*ch; cCnt <= 'Z';cCnt++ )
          {
              cout<<cCnt<<"\t";
              *ch++;
          }
      }
     else if( *ch >= 'a' && *ch <= 'z')
     {
         for(cCnt=*ch ; cCnt >= 'a';cCnt--)
         {
             cout<<cCnt<<"\t";         }
     }
     else
     {
         return;
     }
}

int main()
{
    char cValue[20];


    cout<<"enter character :";
    cin.getline(cValue,20);

    Display(cValue);
 
    return 0;
}