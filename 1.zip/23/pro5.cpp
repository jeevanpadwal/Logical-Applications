//Accept character from user and display its ASCII
// value in decimal and hexadecimal format.

#include<iostream>
using namespace std;

void Display(char ch[])
{

cout<<"Decimal is      :"<< dec <<(int)*ch<<endl;
cout<<"HexaDecimal  is :"<< hex <<(int)*ch<<endl;
cout<<"Octa is         :"<< oct <<(int)*ch<<endl;

}

int main()
{
    char cValue[20];


    cout<<"enter character :";
    cin.getline(cValue,20);

    Display(cValue);
 
    return 0;
}