//Accept character form user and display capital character and if it small then siasply its coreesponding capital in other case display it is 
#include<iostream>
using namespace std;

void Display(char ch[])
{
    
      if( *ch >= 'A' && *ch <='Z')
      {
          *ch= *ch+32;
          cout<<*ch;
      }
     else if( *ch >= 'a' && *ch <= 'z')
     {
         *ch= *ch-32;
         cout<<*ch;
     }
     else
     {
         cout<<*ch;
     }
}

int main()
{
    char cValue[20];


    cout<<"enter character :";
    cin.getline(cValue,20);

    Display(cValue);
 
    return 0;
}