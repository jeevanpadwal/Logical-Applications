//Accept character chk it is spacial symbol ro not 

#include<iostream>
using namespace std;

bool ChkSpacial(char ch[])
{
    char cCnt='\0';
    
      if( *ch >= 32 && *ch <= 42)
      {
          return true;
      }
      else
     {
         return false;
     }
}

int main()
{
    char cValue[20];
    bool bRet;

   cout<<"enter character :";
    cin.getline(cValue,20);

    bRet = ChkSpacial(cValue);

    if(bRet == true)
    {
        cout<<"you Entered Spacial SYmbol";
    }
    else
    {
        cout<<"You Enter Not Spacial Symbol";
    }
 
    return 0;
}