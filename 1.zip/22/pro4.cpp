
//accept charactr and chk small case  or not 
#include<iostream>
using namespace std;

bool ChkSmall(char ch)
{
   if((ch >= 'a')&&(ch<= 'z'))
   {
       return true;
   }
   else
   {
       return false;
   }
 
}

int main()
{
    char cValue='\0';
    bool bRet;

    cout<<"enter character :";
    cin>>&cValue;

    bRet=ChkSmall(cValue);

    if(bRet == true)
    {
        cout<<"Character is Small Case ";

    }
    else 
    {
        cout<<"Characte Not Small Case";
    }

    return 0;
}