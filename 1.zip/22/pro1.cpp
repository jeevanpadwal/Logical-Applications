//accept charactr and chk alphabet or not
#include<iostream>
using namespace std;

bool ChkAlpha(char ch)
{
   if((ch >='a')&&(ch <= 'z')||(ch >= 'A')&&(ch<= 'Z'))
   {
       return true;
   }
   else
   {
       return false;
   }
 
}

int main()
{
    char cValue='\0';
    bool bRet;

    cout<<"enter charter :";
    cin>>&cValue;

    bRet=ChkAlpha(cValue);

    if(bRet == true)
    {
        cout<<"Character is alphabet ";

    }
    else 
    {
        cout<<"Not alphabet";
    }

    return 0;
}