//accept charactr and chk Capital or not
#include<iostream>
using namespace std;

bool ChkAlpha(char ch)
{
   if((ch >= 'A')&&(ch<= 'Z'))
   {
       return true;
   }
   else
   {
       return false;
   }
 
}

int main()
{
    char cValue='\0';
    bool bRet;

    cout<<"enter charter :";
    cin>>&cValue;

    bRet=ChkAlpha(cValue);

    if(bRet == true)
    {
        cout<<"Character is Capital ";

    }
    else 
    {
        cout<<"Not Capital";
    }

    return 0;
}