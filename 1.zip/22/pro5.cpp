
//accept Divisio of student from user and depends on the division displayexam timing ter are $ division in school as A,B,C,D.Exam of division Should display 
#include<iostream>
using namespace std;

void  DisplayShedule(char ch)
{
    int Divison =0;

   if(ch == 'a'||(ch =='A'))
   {
       Divison=1;
   }
   else if(ch == 'b'||ch =='B')
   {
       Divison=2;
   }
   else if(ch == 'c'||ch == 'C')
   {
       Divison=3;
   }
   else if(ch == 'd'|| ch=='D')
   {
       Divison=4;
   }
   else
   {
       cout<<"Wrong Division";
   }

   switch(Divison)
     {    
         case 1:
         cout<<"Your exam at 7 Am";

         break;

         case 2:
         cout<<"your exam at 8.30 Am";
         break;

         case 3:
         cout<<"Your exam at 9.20 Am";
         break;

         case 4:
         cout<<"Your exam at 10.30 Am";
         break;
     }
         





     

 
}

int main()
{
    char cValue='\0';
    bool bRet;

    cout<<"enter Division :";
    cin>>&cValue;

    DisplayShedule(cValue);
   

    return 0;
}