//accept charactr and chk Digit  or not 
#include<iostream>
using namespace std;

bool ChkDigit(char ch)
{
   if((ch >= '0')&&(ch<= '9'))
   {
       return true;
   }
   else
   {
       return false;
   }
 
}

int main()
{
    char cValue='\0';
    bool bRet;

    cout<<"enter character :";
    cin>>&cValue;

    bRet=ChkDigit(cValue);

    if(bRet == true)
    {
        cout<<"Character is Digit ";

    }
    else 
    {
        cout<<"Characte Not Digit";
    }

    return 0;
}