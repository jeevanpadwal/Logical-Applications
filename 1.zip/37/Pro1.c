//in : 5  recurcive
//op :* * * * *
#include<stdio.h>

void Display(int ino)
{
    static int iCnt =0;

    if(iCnt < ino)
    {
           iCnt++;
          printf("*\t");
     
          Display(ino);

    }

}

int main()
{
    int iValue =0;

    printf("Enter number \n");
    scanf("%d",&iValue);

    Display(iValue);

    return 0;
}