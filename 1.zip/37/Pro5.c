//in : 6  recurcive
//op :a b c d e f
#include<stdio.h>

void Display(int ino)
{
    static int iCnt = 0;
    static char ch ='a';
    if(iCnt < ino)
    {
        printf("%c\t",ch);
        ch++;
        iCnt++;
        Display(ino);
    }

}

int main()
{
    int iValue =0;

    printf("Enter number \n");
    scanf("%d",&iValue);

    Display(iValue);

    return 0;
}