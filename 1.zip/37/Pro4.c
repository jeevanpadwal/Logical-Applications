//in : 5  recurcive
//op :A B C D E
#include<stdio.h>

void Display(int ino)
{
    static int iCnt = 0;
    static char ch ='A';
    if(iCnt < ino)
    {
        printf("%c\t",ch);
        ch++;
        iCnt++;
        Display(ino);
    }

}

int main()
{
    int iValue =0;

    printf("Enter number \n");
    scanf("%d",&iValue);

    Display(iValue);

    return 0;
}