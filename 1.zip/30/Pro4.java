//Cheak 7th & 8th & 9th bit is On or Off

import java.lang.*;
import java.util.*;

class Bitwise
{
    public boolean ChkBit(int iNo)
    {
        int iMask = 0X000001C0;
        int iResult = 0;

        iResult = iNo & iMask;

        if(iResult == 0)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

}

class Pro4
{
    public static void main(String a[])
    {
        Scanner sobj = new Scanner(System.in);
        Bitwise bobj = new Bitwise();

        System.out.println("Enter first number :");
        int iValue = sobj.nextInt();

        boolean bRet = bobj.ChkBit(iValue);

        if(bRet == true)
        {
            System.out.println("Bit is on");

        }
        else
        {
            System.out.println("Bit is off");
        }


    }
}