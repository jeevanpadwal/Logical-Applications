//Write a program which accept string fro, user and accept one character cheak
//character and return index of last occarance

#include<iostream>
using namespace std;

int CountChar(char *str,char ch)
{
     int last=0;
     int index=0;
     char *end=str;

      while(*str != '\0' )
      { 
         if(*str == ch )
        {
             last=index;
        }
        index++;
        str++;
    }
    return last;
}

int main()
{
    char cValue[30];
    char cValue1;
    int iRet=0;

    cout<<"enter the string :"<<endl;
    cin.getline(cValue,30);

    cout<<"enter character which find "<<endl;
    cin>>cValue1;

    iRet=CountChar(cValue,cValue1);

    cout<<"Index of character :"<<iRet;

    return 0;
}