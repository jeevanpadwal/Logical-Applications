//Write a program which accept string from user 
//reverse that string in place

#include<iostream>
using namespace std;

int StrRevX(char *str)
{
    char *end=str;
    char *start=str;
    char temp;
 
      while( *end != '\0')
       {
         end++;
       }
       end--;

      while(start <= end )
    { 
        temp = *start;
        *start = *end;
        *end = temp;

        start++;
        end--;

    }

}

int main()
{
    char cValue[30];
   
    cout<<"enter the string :"<<endl;
    cin.getline(cValue,30);

    StrRevX(cValue);

    cout<<"Reverse string  :"<<cValue;

    return 0;
}