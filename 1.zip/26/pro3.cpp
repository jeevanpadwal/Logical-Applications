//Write a program which accept string fro, user and accept one character cheak
//character and return index of first occarance
#include<iostream>
using namespace std;

int CountChar(char *str,char ch)
{
  int iCnt=-1;

    while(*str != '\0')
    {
        iCnt++;
       
         if(*str == ch )
        {
             break;
        }
         str++;

    }

   return iCnt;

}

int main()
{
    char cValue[30];
    char cValue1;
    int iRet=0;

    cout<<"enter the string :"<<endl;
    cin.getline(cValue,30);

    cout<<"enter character which find "<<endl;
    cin>>cValue1;

    iRet=CountChar(cValue,cValue1);

    cout<<"Index of character :"<<iRet;

    return 0;
}