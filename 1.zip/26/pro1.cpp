//Write a program which accept string fro, user and accept one character cheak
//character is preasent   or not
#include<iostream>
using namespace std;

bool ChkChar(char *str,char ch)
{
    int iFlage=0;
    while(*str != '\0')
    {
        if(*str == ch )
        {
            iFlage=1;
        }
         str++;

    }
    if(iFlage == 1)
    {
        return true;
    }
    else
    {

        return false;
    }
   

}

int main()
{
    char cValue[30];
    char cValue1;
    bool bRet;

    cout<<"enter the string :"<<endl;
    cin.getline(cValue,30);

    cout<<"enter character which find "<<endl;
    cin>>cValue1;

    bRet=ChkChar(cValue,cValue1);

    if(bRet == true)
    {
        cout<<"Character found "<<endl;

    }
    else
    {
        cout<<"Character not found ";

    }
  
    return 0;
}