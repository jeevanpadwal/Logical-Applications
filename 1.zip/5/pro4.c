#include<stdio.h>
int MultiDigit(int iNo)
{
    int iMult=1;
    int iDigit=0;

    while(iNo!=0)
    {
        iDigit=iNo%10;
        if(iDigit!=0)
        {      

           iMult=iMult*iDigit;
        }

        iNo=iNo/10;

    }
    return iMult;
}

int main()
{
    int iValue=0;
    int iRet=0;

    printf("enter number");
    scanf("%d",&iValue);

    iRet=MultiDigit(iValue);

    printf("multiplicationn of no. is :%d",iRet);

    return 0;
}