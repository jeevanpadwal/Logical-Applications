#include<stdio.h>

int Differance(int iNo)
{
    int iDigit=0;
    int iAEven=0;
    int iAOdd=0;
    int iDiff=0;

    while(iNo>0)
    {
        iDigit=iNo%10;
        if((iDigit%2)==0)
        {
            iAEven=iAEven+iDigit;
            
        }
        else
        {
            iAOdd=iAOdd+iDigit;
            
        }
        
        iNo=iNo/10;
    }
    iDiff=iAEven-iAOdd;
    return iDiff;
}
int main()
{

    int iValue=0;
    int iRet=0;

    printf("enter the no");
    scanf("%d",&iValue);

    iRet=Differance(iValue);

    printf("differance of even and odd is:%d",iRet);

    return 0;
}