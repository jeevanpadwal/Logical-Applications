// accept n number display divisible by 5 and even 
#include<stdio.h>
#include<stdlib.h>

void DivEven(int Arr[] ,int iLength)
{
     int iCnt=0;
     for(iCnt=0;iCnt<iLength;iCnt++)
     {
         if((((Arr[iCnt]%3)==0)&&((Arr[iCnt]%5)==0)))
         {
             printf("number is :%d",Arr[iCnt]);
         }
     }
}

int main()
    {
int iSize=0;
int *iptr=NULL;
int iCnt=0;

printf("enter the size of elements");
scanf("%d",&iSize);

iptr=(int*)malloc(sizeof(int)*iSize);

printf("enter elements");
for(iCnt=0;iCnt<iSize;iCnt++)
{

 scanf("%d",&iptr[iCnt]);

}

DivEven(iptr,iSize);


        return 0;
    }
