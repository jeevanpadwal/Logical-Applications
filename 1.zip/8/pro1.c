// accept N no. return differance between sum of even and sum of odd 
#include<stdio.h>
#include<stdlib.h>

int Differance(int Arr[],int iLength)
{
    int iCnt=0,iSumE=0,iSumO=0,iDiff=0;

    for(iCnt=0;iCnt<iLength;iCnt++)

    {
        if((Arr[iCnt]%2)==0)
        {
            iSumE=iSumE+Arr[iCnt];
        }
        else if((Arr[iCnt] % 2) != 0)
        {
            iSumO=iSumO+Arr[iCnt];
        }
    }
    iDiff=iSumE-iSumO;
    return iDiff;
}
int main()
{
    int iSize=0,iCnt=0,iRet=0;
    int *ptr=NULL;

    printf("enter the size of arry");
    scanf("%d",&iSize);
    
    
    ptr=(int*)malloc(iSize*sizeof(int));

    printf("enter the elemnts of arry");

    for(iCnt=0;iCnt<iSize;iCnt++)
    {
        scanf("%d",&ptr[iCnt]);
    }

    iRet=Differance(ptr,iSize);

    printf("differance of even elements and odd elements is :%d",iRet);

    return 0;
}