//accept N no. display which divisible by 5 and even
//accept N no. display divisible by 5 


#include<stdio.h>
#include<stdlib.h>

void DivisionEven(int Arr[], int iLength)
{
    int iCnt=0;
    for(iCnt=0;iCnt<iLength;iCnt++)
    {
        if((Arr[iCnt]%5)==0&&(Arr[iCnt]%2)==0)
        {
            printf("number is :%d\n",Arr[iCnt]);
        }
    }
}

int main()
{
    int iSize=0;
    int iCnt=0;
    int *ptr=0;
    int iRet=0;

    printf("enter  how many elemnts \n");
    scanf("%d",&iSize);

    ptr=(int*)malloc(iSize*sizeof(int));

    printf("enter numbe of the arry \n");
    for(iCnt=0;iCnt<iSize;iCnt++)
    {
        scanf("%d",&ptr[iCnt]);
    }
   DivisionEven(ptr,iSize);


 return 0;

}
