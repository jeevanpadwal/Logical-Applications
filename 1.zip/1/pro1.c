#include<stdio.h>
int Divide(int iNo,int iNo1)
{
    int iAns=0;
    if(iNo<0)
    {
        return -1;
    }

    iAns=iNo/iNo1;
    return iAns;
}

int main()
{
int iValue=15;int iValue1=5;
int iRet=0;

iRet=Divide(15,5);
printf("division id %d",iRet);

    return 0;
}