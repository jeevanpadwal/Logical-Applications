//Input:a    output:A
//Input:D    output:d
//convert case
#include<stdio.h>

void DisplayConvert(char CValue)
{
    if()
}


int main()
{
    char cValue='\0';

    printf("enter no");
    scanf("%d",&cValue);

    DisplayConvert(cValue);


    return 0;
}