//input:24
//output:1 2 4 6 8 12
//even factors of that number

#include<stdio.h>

void EvenFactor(int iNo)
{
    int i=0;
    if(iNo<=0)
    {
        iNo=-iNo;
    }
    for(i=1;i<iNo;i++)
    {
        if(((iNo%i)==0)&&((i%2)==0))
        {
            printf("%d\n",i);
        }
    }
}

int main()
{
    int iValue=0;

    printf("enter no\n");
    scanf("%d",&iValue);

    EvenFactor(iValue);

    return 0;
}