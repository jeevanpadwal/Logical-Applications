//in:7
//out:2 4 6 8 10 12 14

#include<stdio.h>
void PrintEven(int iNo)
{
    int iCnt=0;
    int iEcount=0;
    if(iNo<=0)
    {
        return;
    }

    
    for(iCnt=1;iCnt*iNo;iCnt++)
    {
      if((iCnt%2)==0)
        {
            printf("%d\n",iCnt);
            iEcount++;
     
        }
        if(iEcount==iNo)
        {
            break;
        }

    }  


}

int main()
{
    int iValue=0;

    printf("enter no\n");
    scanf("%d",&iValue);

    PrintEven(iValue);

return 0;
}