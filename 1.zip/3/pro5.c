//a,e,i,o,u
//ovel=true
//otherwisw =false

#include<stdio.h>
typedef int bool;

#define TRUE 1
#define FALSE 0

bool ChkVowel(char CB)
{
    if(CB=='a'||CB=='e'||CB=='i'||CB=='o'||CB=='u')
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

int main()
{
char cValue='\0';
bool bRet=FALSE;

printf("Enter character\n");;
scanf("%c",&cValue);

bRet=ChkVowel(cValue);

if(bRet==TRUE)
{
    printf("it is vowel");

}
else
{
    printf("it is not Vowel");
}

return 0;
}