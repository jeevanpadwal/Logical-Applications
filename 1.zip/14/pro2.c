#include<stdio.h>

void Display(int iRow,int iCol)
{
    int i =0,j=0;
    char ch='\0';
    char ch1='\0';

   for(i=1;i<=iRow;i++)
   {
       for(j=1,ch='a',ch1='A';j<=iCol;j++,ch++,ch1++)
    {
         if(i%2==0)
        {
            printf("%c\t",ch);
        }
        else
         {
                //for(j=1,ch='A';j<=iCol;j++,ch++);
            
                printf("%c\t",ch1);
            
          }
    }

          printf("\n");
   }

}

int main()
{
    int iValue1=0,iValue2=0;

    printf("enter value of row and column");
    scanf("%d %d",&iValue1,&iValue2);

    Display(iValue1,iValue2);

    return 0;

}