//in : 5 recurcive
//op : 5 * 4 * 3 * 2 * 1 *

#include<stdio.h>

void Display(int no)
{
    static int iCnt =0;
     
     if(no <= 0)
     {
       return;

     }
     else
     {
         printf("%d\t*\t",no);
         Display(no-1);

     }
}

int main()
{
    int iValue =0;

    printf("Enter value :");
    scanf("%d",&iValue);

    Display(iValue);

    return 0;
}

