//in : 879 recurcive
//op : 24 sum of digit

#include<stdio.h>

int Sum(int no)
{
   static int iDigit =0;
   static int iSum =0;

    if( no != 0)
    {
       iDigit= no % 10;
        iSum=iSum + iDigit;
        no = no/10;
        Display(no);
    }
    return iSum;
}

int main()
{
    int iValue =0;
    int iret =0;

    printf("Enter value :");
    scanf("%d",&iValue);

    iret = Sum(iValue);
    printf("Sum is :%d ",iret);

    return 0;
}

