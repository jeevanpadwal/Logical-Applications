//in : 523   //recurcive
//op : 30  //product of digit

#include<stdio.h>

int Mult(int no)
{
   static int iCnt =0;
   static int iDigit =0;
   static int iMult =1;

    if(no <=0 )
    {
       return 0;    
    }
    else
    {
        iDigit = no %10;

        iMult= iMult * iDigit;

        no = no/10;   

        Mult(no);
    }
    return iMult;
}

int main()
{
   int iRet =0;
   int iValue =0;

   printf("Enter number :");
   scanf("%d",&iValue);

   iRet = Mult(iValue);

   printf("%d",iRet);

    return 0;
}

