//in : 5   //recurcive
//op : 120  //factorial

#include<stdio.h>

int Fact(int no)
{
   static int iCnt =1;
   static int iMult =1;

      
   
    if(no <=0 )
    {
       return 0;    
    }
    else
    {
        iMult = iCnt * iMult;
        iCnt++;
        no--;
        Fact(no);
    }
    return iMult;
}

int main()
{
   int iRet =0;
   int iValue =0;

   printf("Enter number :");
   scanf("%d",&iValue);

   iRet = Fact(iValue);

   printf("%d",iRet);

    return 0;
}

