//accept string and cheak vowels or not

#include<iostream>
using namespace std;
bool CountVowel(char *ch)
{
    int iFlage=0;

    while( *ch != '\0')
    {
       if(*ch =='a'||*ch =='e'||*ch =='i'||*ch =='o'||*ch =='u'||*ch =='A'||*ch =='E'||*ch =='I'||*ch =='O'||*ch =='U')
       {
           iFlage=1;

       }
      
        ch++;
    }
    if(iFlage==1)
    {
        return true;
    }
    else
    {
        return false;
    }


   

}

int main()
{
    char cValue[30];
    bool bRet;

    cout<<"enter the string "<<endl;
    cin.getline(cValue,30);

    bRet=CountVowel(cValue);
    
    if(bRet == true)
    {
        cout<<"String Contains Vowels";
    }
    else
    {
        cout<<"Sting Not conatin vowels";
    }
    return 0;
}
