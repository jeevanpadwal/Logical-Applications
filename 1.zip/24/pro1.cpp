//accept string from user and count number of capita character
#include<iostream>
using namespace std;

int CountCapital(char *ch)
{
    int iCnt=0;

    while( *ch != '\0')
    {
        if(*ch >='A'&& *ch <='Z')
        {
           iCnt++;
        }
        ch++;
    }
    return iCnt;

}

int main()
{
    char cValue[30];
    int iRet=0;

    cout<<"enter the string "<<endl;
    cin.getline(cValue,30);

    iRet=CountCapital(cValue);
    cout<<"Capital letter is :"<<iRet<<endl;

    return 0;
}
