//accept string from user and count number of Small character
#include<iostream>
using namespace std;

int CountSmall(char *ch)
{
    int iCnt=0;

    while( *ch != '\0')
    {
        if(*ch >='a'&& *ch <='z')
        {
           iCnt++;
        }
        ch++;
    }
    return iCnt;

}

int main()
{
    char cValue[30];
    int iRet=0;

    cout<<"enter the string "<<endl;
    cin.getline(cValue,30);

    iRet=CountSmall(cValue);
    cout<<"Small letter is :"<<iRet<<endl;

    return 0;
}
