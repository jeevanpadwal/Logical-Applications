//accept string from user and count differanc  of capita and 
// small character
#include<iostream>
using namespace std;

int CountDifferance(char *ch)
{
    int iCapital=0;
    int iSmall=0;
    int iCnt=0;

    while( *ch != '\0')
    {
        if(*ch >='A'&& *ch <='Z')
        {
           iCapital++;
           cout<<*ch<<endl;
        }
      else  if(*ch >='a'&& *ch <='z')
        {
           iSmall++;
           cout<<*ch<<endl;
        }
        ch++;
    }

    iCnt = iSmall - iCapital;
    return iCnt;

}

int main()
{
    char cValue[30];
    int iRet=0;

    cout<<"enter the string "<<endl;
    cin.getline(cValue,30);

    iRet=CountDifferance(cValue);
    cout<<"Differance betwwen small and Capital letter is :"<<iRet<<endl;

    return 0;
}
