//accept string and Display Reverse

#include<iostream>
using namespace std;
void  Reverse(char *ch)
{
    char *start = ch;
    char *end = ch;
    char temp;

    while( *end != '\0')
    {
        end++;
    }
    end--;
   
    while(start <= end)
    {

        temp=*start;
        *start=*end;
        *end=temp;

        start++;
        end--;
       
    }

}

int main()
{
    char cValue[30];
    bool bRet;

    cout<<"enter the string "<<endl;
    cin.getline(cValue,30);

    Reverse(cValue);

    cout<<cValue<<endl;
    
   
    return 0;
}
