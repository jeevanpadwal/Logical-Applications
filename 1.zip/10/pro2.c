#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>


int ChkNo(int Arr[],int iLength,int iNo)
{

int iCnt=0;
bool bFlag=false;

for(iCnt=0;iCnt<iLength;iCnt++)
{
    if(Arr[iCnt]==iNo)
    {
     break;

    }
    
}
  if(iCnt==iLength)
  {
      return -1;
  }
  else
  {
      return iCnt;

  }

}


int main()
{
    int iSize=0,iCnt=0,iValue;
    int *iptr=NULL;
    int iRet=false;

    printf("enter size of arry\n");
    scanf("%d",&iSize);

    iptr=(int*)malloc(sizeof(int)*iSize);

    printf("enter elements \n");

    for(iCnt=0;iCnt<iSize;iCnt++)
    {
        scanf("%d",&iptr[iCnt]);
    }

    printf("emter number which want search");
    scanf("%d",&iValue);

    iRet=ChkNo(iptr,iSize,iValue);

   if(iRet== -1)
   {
       printf("no number");
   }
   else
   {
       printf("first occurance at index :%d",iRet);
   }

    free(iptr);



return 0;
    

}