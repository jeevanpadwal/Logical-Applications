#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>


int Mult(int Arr[],int iLength)
{

int iCnt=0;
int iMult=1;

for(iCnt=0;iCnt<iLength;iCnt++)
{
    if((Arr[iCnt]%2)!=0)
    {
     iMult=iMult*(Arr[iCnt]);

    }
    
}
  return iMult;
}


int main()
{
    int iSize=0,iCnt=0,iValue;
    int *iptr=NULL;
    int iRet=0;;

    printf("enter size of arry\n");
    scanf("%d",&iSize);

    iptr=(int*)malloc(sizeof(int)*iSize);

    printf("enter elements \n");

    for(iCnt=0;iCnt<iSize;iCnt++)
    {
        scanf("%d",&iptr[iCnt]);
    }

   

    iRet=Mult(iptr,iSize);

   printf("multiplication is: %d",iRet);

    free(iptr);



return 0;
    

}