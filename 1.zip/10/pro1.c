#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>


bool ChkNo(int Arr[],int iLength,int iNo)
{

int iCnt=0;
bool bFlag=false;

for(iCnt=0;iCnt<iLength;iCnt++)
{
    if(Arr[iCnt]==iNo)
    {
        bFlag=true;
    }
    return bFlag;
}


}


int main()
{
    int iSize=0,iCnt=0,iValue;
    int *iptr=NULL;
    bool bRet=false;

    printf("enter size of arry\n");
    scanf("%d",&iSize);

    iptr=(int*)malloc(sizeof(int)*iSize);

    printf("enter elements \n");

    for(iCnt=0;iCnt<iSize;iCnt++)
    {
        scanf("%d",&iptr[iCnt]);
    }

    printf("emter number which want search");
    scanf("%d",&iValue);

    bRet=ChkNo(iptr,iSize,iValue);

    if(bRet==true)
    {
        printf("TRUE");
    }
    else
    {
        printf("FALSE");

    }

    free(iptr);



return 0;
    

}