#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>


void Range(int Arr[],int iLength,int iNo1,int iNo2)
{

 int iCnt=0;


 for(iCnt=0;iCnt<iLength;iCnt++)
  {
     if(((Arr[iCnt])>=iNo1)&&(Arr[iCnt])<=iNo2)
    {
      printf("%d\n",Arr[iCnt]);

    }
    
  }

}


int main()
{
    int iSize=0,iCnt=0,iValue1=0,iValue2=0;
    int *iptr=NULL;
    

    printf("enter size of arry\n");
    scanf("%d",&iSize);

    iptr=(int*)malloc(sizeof(int)*iSize);

    printf("enter elements \n");

    for(iCnt=0;iCnt<iSize;iCnt++)
    {
        scanf("%d",&iptr[iCnt]);
    }

    printf("emter range of starting number");
    scanf("%d",&iValue1);

    printf("enter the end number");
    scanf("%d",&iValue2);

    Range(iptr,iSize,iValue1,iValue2);

   


return 0;
    

}