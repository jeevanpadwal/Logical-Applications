import java.lang.*;
import java.util.*;
import java.io.*;

class File_Operation
{
    public static long getFileSize(String filename)
    {
       File file = new File(filename);
      if (!file.exists() || !file.isFile()) {
         System.out.println("File doesn\'t exist");
         return -1;
      }
      return file.length();
    }

   void CopyFileData(String folder) throws IOException
   {
      Scanner sobj = new Scanner(System.in);
      File path = new File("C:/Users/G1/Desktop/LBA/"+folder);

      System.out.println("Enter file name for copy file names :");
      String file =sobj.nextLine();

      File dest = new File("C:/Users/G1/Desktop/LBA/assignment44/"+file);
      boolean flag = dest.createNewFile();
      if(flag == true)
      {
         System.out.println("File Created succesfull");
      }
      else
      {
          System.out.println("File alredy present ");
      }
         FileWriter fWriter = new FileWriter(dest,true);
         String content[] =path.list();
      
      for(int i=0 ; i < content.length; i++)
      {
          Scanner scan1 = new Scanner(content[i]);
          String line1 = scan1.nextLine();
          fWriter.write(line1+"\n");

          File path1 = new File(path+"/"+content[i]);
          Scanner scan = new Scanner(path1);

        long size1 = getFileSize(content[i]);
        fWriter.write(size1+"\n");
        
          while(scan.hasNextLine())
         {
             String line = scan.nextLine();
             fWriter.write(line+"\n");
         }
        
      }
      fWriter.close();
      System.out.println("directory data copy to the path :"+dest);
   }

}
class Pro5
{
   public static void main(String a[]) throws IOException,FileNotFoundException
   {
      Scanner sobj = new Scanner(System.in);
      File_Operation foobj = new File_Operation();

      System.out.println("Enter directory name :");
      String folder = sobj.nextLine();

      foobj.CopyFileData(folder);

   }
}