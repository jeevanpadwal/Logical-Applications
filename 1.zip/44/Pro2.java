import java.lang.*;
import java.util.*;
import java.io.*;

class File_Operation
{
   void CopyFileName(String folder) throws IOException
   {
      Scanner sobj = new Scanner(System.in);
      File path = new File("C:/Users/G1/Desktop/LBA/"+folder);

      System.out.println("Enter file name for copy file names :");
      String file =sobj.nextLine();

      File dest = new File("C:/Users/G1/Desktop/LBA/assignment44/"+file);
      boolean flag = dest.createNewFile();
      if(flag)
      {
         
        System.out.println("File Created succesfull");
      }
      else
      {
         
        System.out.println("File alredy present ");
      }
      FileWriter fWriter = new FileWriter(dest,true);
      String content[] =path.list();
      for(int i=0 ; i < content.length; i++)
      {
         Scanner scan = new Scanner(content[i]);
        String line = scan.nextLine();
         fWriter.write(line+"\n");
      }
      fWriter.close();
      System.out.println("File names copy to the path :"+dest);
   }

}
class Pro2
{
   public static void main(String a[]) throws IOException,FileNotFoundException
   {
      Scanner sobj = new Scanner(System.in);
      File_Operation foobj = new File_Operation();

      System.out.println("Enter directory name :");
      String folder = sobj.nextLine();

      foobj.CopyFileName(folder);


   }
}