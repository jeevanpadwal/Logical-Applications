import java.lang.*;
import java.util.*;
import java.io.*;

class File_Operation
{
    void DisplyReguler(String name)
    {
        File path = new File("C:/Users/G1/Desktop/LBA/"+name);

        String namesOfFiles[] = path.list();

        for(int i=0; i < namesOfFiles.length ; i++)
        {
           File file = new File("C:/Users/G1/Desktop/LBA/"+name+namesOfFiles[i]);
           System.out.println(namesOfFiles[i]) ;
           
            if(!file.isRegularFile())
            {
                System.out.println("File is reguler :");
            }
            else
            {
                 System.out.println("File is not reguler :");   
            }
        }
    }
}

class Pro1
{
    public static void main(String a[])throws ArrayIndexOutOfBoundsException
    {
        Scanner sobj = new Scanner(System.in);
        File_Operation foobj = new File_Operation();

        System.out.println("Enter directory name :");
        String name = sobj.nextLine();

        foobj.DisplyReguler(name);
    }
}