//accept two numbers from user and display first number in second number of time 
//input 12 5
//output 12  12  12  12  12

#include<stdio.h>

void Display(int iNo,int iFrequency)
{   
    if(iFrequency<0)
    {
        iFrequency=-iFrequency;
    }
    int iCnt=0;
    
        for(iCnt=1;iCnt<=iFrequency;iCnt++)
        {
           printf("%d\n",iNo);
        }
}
int main()
{
    int iValue=0;
    int iCount=0;

    printf("enter the no");
    scanf("%d",&iValue);

    printf("enter the frequency");
    scanf("%d",&iCount);

    Display(iValue,iCount);

    return 0;
}