//accept on nuber from user if number is less than 10 then print "hello"other wise print "Demo"

#include<stdio.h>
void Display(int iNo)
{
    if(iNo<=10)
    {
        printf("Hello");
    }
    else
    {
        printf("Demo");
    }
}

int main()
{
int iValue=0;
printf("enter no");
scanf("%d",&iValue);

Display(iValue);

    return 0;
}