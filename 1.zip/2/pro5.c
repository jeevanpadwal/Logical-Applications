//accept number from user and cheak whether number is even or odd
#include<stdio.h>

int Cheaker(int iNo)
{
 if(iNo%2)
    {
        printf("number is even");
    }

 else
    {
        printf("number is odd");
    }
}

int main()
{
 int iValue=0;
printf("enter no");
scanf("%d",&iValue);

Cheaker(iValue);

    return 0;
}