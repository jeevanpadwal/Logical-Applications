//accept string and copy content into anather string

#include<iostream>
using namespace std;

void StrCpy(char *src,char *dest)
{
    while( *src != '\0')
    {
        *dest=*src;
        src++;
        dest++;
    }
    *dest='\0';

}

int main()
{
   char Arr[30];
   char Brr[30];

   cout<<"enter a string"<<endl;
   cin.getline(Arr,30);

   StrCpy(Arr,Brr);

   cout<<"Coped string is :"<<Brr<<endl;



    return 0;
}