//accept string and get 1 number copy content into anather string

#include<iostream>
using namespace std;

void StrCpyX(char *src,char *dest,int iCnt)
{
    while( *src != '\0' && iCnt != 0)
    {
        *dest=*src;
        src++;
        dest++;
        iCnt--;
    }
    *dest='\0';

}

int main()
{
   char Arr[30];
   char Brr[30];
   int Num=0;

   cout<<"enter a string"<<endl;
   cin.getline(Arr,30);

   cout<<"how many character copy :"<<endl;
   cin>>Num;

   StrCpyX(Arr,Brr,Num);

   cout<<"Coped string is :"<<Brr<<endl;



    return 0;
}