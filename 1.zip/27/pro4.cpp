//accept string and get 1 number copy content into anather string

#include<iostream>
using namespace std;

void StrCpySmall(char *src,char *dest)
{
    while( *src != '\0')
    {
        if(*src >= 'a' && *src <= 'z')
        {
            *dest = *src;
            dest++;
        }
        src++;

    }
    *dest='\0';

}

int main()
{
   char Arr[30];
   char Brr[30];

   cout<<"enter a string"<<endl;
   cin.getline(Arr,30);

   StrCpySmall(Arr,Brr);

   cout<<"Coped string is :"<<Brr<<endl;



    return 0;
}