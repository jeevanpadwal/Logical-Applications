#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
};

typedef struct node NODE;
typedef struct node * PNODE;
typedef struct node **PPNODE;

void InsertFirst(PPNODE head,int no)
{
     PNODE newn=NULL;

     newn=(PNODE)malloc(sizeof(NODE));

     newn->data=no;
     newn->next=NULL;

     if(*head==NULL)
     {
         *head=newn;
     }
     else
     {
         newn->next=*head;
         *head=newn;

     }
}
void Display(PNODE head)
{
     while(head!=NULL)
     {
         printf("|%d|->",head->data);

         head=head->next;
     }
     printf("SAMPLI\n");
}

int Maximum(PNODE head)
{
    int iMax=0;
    while(head!=NULL)
    {
        if(iMax<head->data)
        {
            iMax=head->data;
        }

        head=head->next;
    }
    return iMax;
}

int main()
{
PNODE first=NULL;
int ret=0;

InsertFirst(&first,110);
InsertFirst(&first,230);
InsertFirst(&first,320);
InsertFirst(&first,240);

Display(first);

ret=Maximum(first);
printf("Maximum number is :%d\n",ret);


return 0;
}
