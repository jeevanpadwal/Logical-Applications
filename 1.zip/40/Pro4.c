//get neme of file and open that file
//Display All data on consol of that file


#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

#define BLOCK 1024

void FileSize(char Fname[])
{
    int FD =0;
    int iRet =0;
    int wRet =0;
    int Buffer[BLOCK];

    FD = open(Fname,O_RDWR);

    if(FD == -1)
    {
        printf("Unable to open file ");
        return;
    }
    else
    {
        printf("File open Successfully \n");
    }

     while((iRet = read(FD,Buffer,BLOCK)) != 0)
     {
         wRet = write(1,Buffer,iRet);
     }

     printf("\n File Size is %d bytes \n",wRet);

}

int main()
{
    char Fname[30];

    printf("Enter file Name :");
    scanf("%s",Fname);

    FileSize(Fname);
}