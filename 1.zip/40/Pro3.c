//accept name of file and creat that file

#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

void CreatFile(char Fname[])
{
    int FD = 0;

    FD = creat(Fname,0777);

    if(FD == -1)
    {
        printf("Unable to creat ");
    }
    else
    {
        printf("File created successfull ");
    }

}

int main()
{
    char Fname[30];

    printf("Enter file name :\n");
    scanf("%s",Fname);

    CreatFile(Fname);

    return 0;
}