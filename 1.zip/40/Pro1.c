//get neme of file and open that file
//return "File gets open success fully"

#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

void OpenFile(char Fname[])
{
    int FD =0;

    FD = open(Fname,O_RDONLY);

    if(FD == -1)
    {
        printf("Unable to open file ");
        return;
    }
    else
    {
        printf("File open Successfully ");
    }
}

int main()
{
    char Fname[30];

    printf("Enter file Name :");
    scanf("%s",Fname);

    OpenFile(Fname);
}