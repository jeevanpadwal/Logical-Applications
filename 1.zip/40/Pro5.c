//get neme of file and open that file
//Display All data on consol of that file


#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<string.h>

#define BLOCK 1024

void FileData(char Fname[],char Data[])
{
    int FD =0;
    int iRet =0;
    int wRet =0;
    int Buffer[BLOCK];

    FD = open(Fname,O_RDWR | O_APPEND);

    if(FD == -1)
    {
        printf("Unable to open file ");
        return;
    }
    else
    {
        printf("File open Successfully \n");
    }

      write(FD,Data,strlen(Data));
}

int main()
{
    char Fname[30];
    char Data[BLOCK];

    printf("Enter file Name :");
    scanf("%s",Fname);

    printf("Enter string to write after file data \n");
    scanf(" %[^'\n']s",Data);

    FileData(Fname,Data);
}